#include <iostream>
#include <string>
using namespace std;


int main (){
    
    cout << "user input " << endl;


    return 0;
}

