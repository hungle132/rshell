#ifndef __menu_hpp__
#define __menu_hpp__

#include <string>
#include <vector>



class Menu {
	public:

	Menu(){};

	virtual void run(){};
};


#endif //__menu_hpp__	
