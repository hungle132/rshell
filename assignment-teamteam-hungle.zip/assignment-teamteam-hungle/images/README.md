OMT DIAGRAM

![Image of OMT Diagram](https://i.gyazo.com/6b32074347751aa4354e11be5aedf1d3.png)

Class DIAGRAM
![Image of Class](https://i.gyazo.com/0e9e9861a5925ff66465f15b1d1b5cc3.png)
